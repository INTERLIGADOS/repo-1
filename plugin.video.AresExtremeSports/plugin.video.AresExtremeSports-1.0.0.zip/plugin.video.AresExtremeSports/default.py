import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.AresExtremeSports'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "PL16FrVP89GvutriHezhFyqbK3M6cpPbqK"
YOUTUBE_CHANNEL_ID_2 = "PLo6MrktVVANpLRULBOoUWTyU-NaSl3P1y"
YOUTUBE_CHANNEL_ID_3 = "PL16FrVP89GvutriHezhFyqbK3M6cpPbqK"
YOUTUBE_CHANNEL_ID_4 = "PLo6MrktVVANoeveIYzlcD_u1ZBX01BrJd"
YOUTUBE_CHANNEL_ID_5 = "PLt9CNLiMdrSsCZoqtcvOJRHIUGuMK6FB1"
YOUTUBE_CHANNEL_ID_6 = "PL8FCEEA98B156E0B9"
YOUTUBE_CHANNEL_ID_7 = "PL9EM8NJvc22QQJc1GR_8Uu6I1a7O7bRXa"
YOUTUBE_CHANNEL_ID_8 = "PLN2JMLyX5Jckv9wilynVC064sH2YF02P7"
YOUTUBE_CHANNEL_ID_9 = "PLiEINnZsanNTUzTUrE6y7wHOKBsZUDfBX"
YOUTUBE_CHANNEL_ID_10 = "PLB3FnBA-48BED8VsTro4T0-emKTPWI7iK"
YOUTUBE_CHANNEL_ID_11 = "PLyyR6FiQI39fQTNRo-OQLdm2SnGLO8cQ9"
YOUTUBE_CHANNEL_ID_12 = "PL9B30890AAE0FA06E"
YOUTUBE_CHANNEL_ID_13 = "PLZfhJbHjDHamRH300QWhhjE2Z0P0E_NPo"
YOUTUBE_CHANNEL_ID_14 = "PLmbvVWptdFm192NUMYfco3vwnZKaVGHe2"
YOUTUBE_CHANNEL_ID_15 = "PLBeHYvz79ZP1U2L4PF0S-kXeXqM-nn2xG"
YOUTUBE_CHANNEL_ID_16 = "PLyyR6FiQI39fT2j9WdemlcUSyOMYDktEx"
YOUTUBE_CHANNEL_ID_17 = "PLoWj4jhBulB5Znm_SAtM6vP4T63PEMT6c"
YOUTUBE_CHANNEL_ID_18 = "PLaXWjn2EfstzHY6j-ekov1PSStgy_tgi1"
YOUTUBE_CHANNEL_ID_19 = "PLncbAl11hGrCYfM3S6oGjxdDoP2EmCTyx"
YOUTUBE_CHANNEL_ID_20 = "PLTlm-fC_jd1Kl7SiC5_alqFNXRqQvGAmf"
YOUTUBE_CHANNEL_ID_21 = "PL24XBSk6XzzPIatCSoiDX9NX56Bh_Mgbu"
YOUTUBE_CHANNEL_ID_22 = "PLdCPbao5NB-QjiO656jzReFT9M2BsbM6r"
YOUTUBE_CHANNEL_ID_23 = "PLYQWOV6gNS3GoD9v6jPH0ju4glNE-CB3h"
YOUTUBE_CHANNEL_ID_24 = "PLWI4RsIhGtwaRUj8CoBUH-1iv8d8v62sJ"
YOUTUBE_CHANNEL_ID_25 = "PL_v7q7i1iZ1vK5C2QvpMN2zpe2cn20Nig"
YOUTUBE_CHANNEL_ID_26 = "PL-CTTdieQaCdy7WfOp4YGmtjbh0RffC08"
YOUTUBE_CHANNEL_ID_27 = "PLgD2vz3plKIdcKLeGr9on1jSyysHQ5MLj"
YOUTUBE_CHANNEL_ID_28 = "PLH4HIAY31IJ9X8EA81i4H4K80hEQvyg80"
YOUTUBE_CHANNEL_ID_29 = "PLrpSNoXKB8GmognAut2ebAuKcg-wo_e7M"
YOUTUBE_CHANNEL_ID_30 = "PLCJ711eXTDtFuc-rJmAnSc9EIP8ZXW9Cb"
YOUTUBE_CHANNEL_ID_31 = "PLmw7ub9Mei4neBoNNThYaw8O8Z8Ie-tQi"
YOUTUBE_CHANNEL_ID_32 = "PL5oXHyJAxi_hwnT5KjH_1IeSj0MVC7Rty"
YOUTUBE_CHANNEL_ID_33 = "PLC6OXkB_yhBHfmN5_yiKvT36PlVmVPffS"
# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
	
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Parkour[/COLOR] [COLORred]1[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://c1.staticflickr.com/3/2241/2071223678_bd0ae11bc6_z.jpg?zz=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Parkour[/COLOR] [COLORred]2[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://c1.staticflickr.com/1/52/124836531_2f6dbb0c3b_z.jpg?zz=1",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Parkour[/COLOR] [COLORred]3[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://c1.staticflickr.com/1/50/127013009_08b0e46f73_z.jpg?zz=1",
        folder=True )
     
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Learn[/COLOR] [COLORred]Parkour[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="http://wallpaperpulse.com/thumb/1542963.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Parkour/Freerunning[/COLOR] [COLORred]Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="http://joiningallmovement.com/wp-content/uploads/2013/05/parkour_and_training_banner.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Skateboarding[/COLOR] [COLORred]1[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQbqFBkrdgAclCRxexjZp8dQYp9wrZL1wANCwGlzvBNTQhydUdn",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Skateboarding[/COLOR] [COLORred]2[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="http://www.nkcf.org/wp-content/uploads/2014/06/21110-Longboard-Lifestyle.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Vintage[/COLOR] [COLORred]Skateboarding[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="http://www.orangecountylofts.com/images/skateboarding.jpg",
        folder=True )
     
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Skateboarding[/COLOR] [COLORred]Movies[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="http://umad.com/img/2016/8/skateboarding-wide-hd-wallpaper-12980-13433-hd-wallpapers.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Tony Hawk[/COLOR] Skateboarding [COLORred]Music[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="http://www3.pictures.zimbio.com/gi/Tony+Hawk+Coachella+Music+Festival+Day+1+-YLX9IbWBsal.jpg",
        folder=True )
     
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Extreme[/COLOR] Sports [COLORred]1[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="http://extremeinsanity.net/assets/4.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Extreme[/COLOR] Sports [COLORred]2[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://s-media-cache-ak0.pinimg.com/originals/5b/74/cc/5b74cc1c3b56943403c6f3734e5a1b94.jpg",
        folder=True )
     
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Extreme[/COLOR] [COLORred]1[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="http://www.extremesportscompany.com/img/extreme-sports.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Extreme[/COLOR] [COLORred]2[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="http://www.extremesportscompany.com/img/extreme-sports.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Extreme[/COLOR] [COLORred]3[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="http://www.extremesportscompany.com/img/extreme-sports.jpg",
        folder=True )
    	
    plugintools.add_item( 
        #action="", 
        title="[COLORred]RedBull[/COLOR] [COLORyellow]Sports[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="http://e0.365dm.com/16/02/16-9/20/red-bull-f1_3417536.jpg?20160217220257",
        folder=True )
      
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Bungee[/COLOR] [COLORred]Jumping[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="http://whenonearth.net/wp-content/uploads/2014/10/great-bungee-jumping.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Weapons[/COLOR] [COLORred]Testing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="http://www.paxchristi.it/wp-content/uploads/2017/03/us-army-2.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Mountaineering[/COLOR] [COLORred]Documentaries[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="http://www.alphamountaineering.co.uk/contact/kyrgyzstanCrop.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Mountain[/COLOR] [COLORred]Boarding[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="http://www.remolition.com/wp-content/uploads/2016/09/Mountainboard-World_BX-Champs-2016-Remolition-cover.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Mountain[/COLOR] [COLORred]Biking[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="http://www.visitgarda.com/upload/cms/400_x/Mountain%20bike%20sul%20Lago%20di%20Garda(1).jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Free[/COLOR] [COLORred]Climbing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="https://www.travelwaw.com/wp-content/uploads/2017/03/solo-climb.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Drifting[/COLOR] & [COLORred]Ken Block[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://s-media-cache-ak0.pinimg.com/originals/d7/a1/84/d7a1842818d4f735e2947f8f71fa9aa0.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Moto[/COLOR][COLORred]cross[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="https://cloud.yamahamotorsports.com/library/img.jpg?id=5751bb672a0ab65718d843e7&w=840",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]BMX[/COLOR] [COLORred]Freestyle[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="http://www.fosilfueled.com/wp-content/uploads/2013/10/freestyle_friday_019_10252013.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Surfing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="http://i.dailymail.co.uk/i/pix/2014/09/29/1411971085370_wps_2_A_dog_surfs_at_the_6th_An.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Body[/COLOR][COLORred]Boarding [/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="http://www.xtremespots.com/wp-content/uploads/2013/05/Bodyboarding-at-Virginia-Beach.png",
        folder=True )
     
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Water[/COLOR][COLORred]Skiing [/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="https://img.grouponcdn.com/deal/dF9yHBUkQGefvehRZ5EC/Eq-700x420/v1/c700x420.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Jet[/COLOR] [COLORred]Skiing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="http://shared.findaportal.com/websites/986/uploadedimages/CI986ID20791PH3.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Snow[/COLOR][COLORred]boarding[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="https://www.snowskool.com/uploads/images/Snowboarding_and_Skiing%2C_Featured_Image.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Base[/COLOR] [COLORred]Jumping[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="http://i.telegraph.co.uk/multimedia/archive/02257/potd-base-jump_2257955b.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Sky[/COLOR] [COLORred]Diving[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="http://upload1.mimoshow.com.au/wp-content/uploads/2015/06/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2015-06-11-%E4%B8%8B%E5%8D%885.42.37.png",
        folder=True )
    
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Drone[/COLOR] [COLORred]Racing[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="https://www.heroblog.it/wp-content/uploads/2016/05/inverse-.-com-760x426.jpeg",
        folder=True )
run()