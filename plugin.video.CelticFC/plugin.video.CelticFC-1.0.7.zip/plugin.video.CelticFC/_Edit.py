import xbmcaddon

MainBase = 'https://goo.gl/2pktLT'
addon = xbmcaddon.Addon('plugin.video.CelticFC')