'''
    Copyright (C) 2017 THFC Zone,BigYidBuilds

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import urllib
import urllib2
import datetime
import re
import os
import base64
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import cookielib
import time
import requests

def resolve(url): 
    play=xbmc.Player()
    import urlresolver
    try: play.play(url)
    except: pass
	
def resolve_check(url):
	try:
		urllib2.urlopen(url)
		try:
			play=xbmc.Player()
			import urlresolver
			try: play.play(url)
			except: pass
		except: pass
	except urllib2.URLError,e:
		message = 'Link Removed'
		executebuiltin_not(message)
		
	
def resolve_cdn(url):
	if 'http' not in url:
		url = 'http:'+url
	else:pass 
	try:
		urllib2.urlopen(url)
		try:
			url = 'plugin://plugin.video.f4mTester/?url='+url+'&amp;streamtype=HLSRETRY'
			play=xbmc.Player()
			import urlresolver
			try:play.play(url)
			except: pass
		except:
			pass
	except urllib2.URLError,e:
		try:
			url=(url).replace('18465','21772')
			urllib2.urlopen(url)
			xbmc.executebuiltin("XBMC.Notification(THFC Zone,Changing play mode please wait,10000,"+icon+")")
			try:
				url = 'plugin://plugin.video.f4mTester/?url='+url+'&amp;streamtype=HLSRETRY'
				play=xbmc.Player()
				import urlresolver
				try:play.play(url)
				except: pass
			except:
				pass
		except:
			pass

def resolve_f4m(url):
	if not url.startswith('http'):
		url = 'http'+url
	if url.endswith('.ts'):
		url = 'plugin://plugin.video.f4mTester/?url='+url+'&amp;streamtype=TSDOWNLOADER'
	if url.endswith('.m3u8'):
		url = 'plugin://plugin.video.f4mTester/?url='+url+'&amp;streamtype=HLSRETRY'
	else:
		url = 'plugin://plugin.video.f4mTester/?url='+url
	play=xbmc.Player()
	import urlresolver
	try: play.play(url)
	except:
		pass
			
def resolve_f4m_ts(url):
	url = 'plugin://plugin.video.f4mTester/?url=http'+url+'&amp;streamtype=TSDOWNLOADER'
	play=xbmc.Player()
	import urlresolver
	try: play.play(url)
	except:
		pass

def resolve_f4m_m3u8(url):
	url = 'plugin://plugin.video.f4mTester/?url=http'+url+'&amp;streamtype=HLSRETRY'
	play=xbmc.Player()
	import urlresolver
	try: play.play(url)
	except:
		pass
		
def resolve_sportsdevil(url): 
	play=xbmc.Player()
	url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url='+url
	import urlresolver
	try: play.play(url)
	except:
		pass

def resolve_highlight_player(url):
	try:
		urllib2.urlopen(url)
		try:
			play=xbmc.Player()
			import urlresolver
			try: play.play(url)
			except:
				pass
		except:
			pass
	except urllib2.URLError,e:
		xbmc.executebuiltin("XBMC.Notification(THFC Zone,Link removed for copyright,10000,"+icon+")")