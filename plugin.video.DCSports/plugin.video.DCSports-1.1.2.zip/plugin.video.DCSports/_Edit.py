import xbmcaddon

MainBase = 'https://goo.gl/mhKkdj'
addon = xbmcaddon.Addon('plugin.video.DCSports')