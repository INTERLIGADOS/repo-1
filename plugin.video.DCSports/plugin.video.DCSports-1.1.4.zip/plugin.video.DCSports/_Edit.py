import xbmcaddon

MainBase = 'https://www.dropbox.com/s/hb8y537p7zvbjtx/newhomemain.txt?dl=1'
addon = xbmcaddon.Addon('plugin.video.DCSports')