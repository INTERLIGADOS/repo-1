import xbmcaddon

MainBase = 'https://goo.gl/Ps5HhT'
addon = xbmcaddon.Addon('plugin.video.DCSports')