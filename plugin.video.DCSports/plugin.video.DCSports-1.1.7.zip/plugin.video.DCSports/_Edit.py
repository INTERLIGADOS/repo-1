import xbmcaddon

MainBase = 'https://goo.gl/8ME9fM'
addon = xbmcaddon.Addon('plugin.video.DCSports')