import xbmcaddon

MainBase = 'https://goo.gl/LmbJZ2'
addon = xbmcaddon.Addon('plugin.video.MyAnimasi')