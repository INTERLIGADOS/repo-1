import xbmcaddon

MainBase = 'https://goo.gl/efkdn7'
addon = xbmcaddon.Addon('plugin.video.britishzone')