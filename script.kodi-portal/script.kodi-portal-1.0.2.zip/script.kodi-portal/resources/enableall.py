import xbmc
xbmc.executebuiltin('XBMC.RunScript(script.kodi-portal,enableall)')